package com.project.foodfix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodFixApplication {

    public static void main(String[] args) {
        SpringApplication.run(FoodFixApplication.class, args);
    }

}
