package com.project.foodfix;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan("com.project.foodfix.mapper")
public class MyBatisConfig {
}
