package com.project.foodfix.controller;

import com.project.foodfix.mapper.AdminMapper;
import com.project.foodfix.mapper.StoreMapper;
import com.project.foodfix.model.Admin;
import com.project.foodfix.model.Menu;
import com.project.foodfix.model.dto.AdminDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final AdminMapper adminMapper;
    private final StoreMapper storeMapper;

    @Autowired
    public AdminController(AdminMapper adminMapper, StoreMapper storeMapper) {
        this.adminMapper = adminMapper;
        this.storeMapper = storeMapper;
    }

    // 관리자 정보 조회
    @GetMapping("/info/{admin_phone}")
    public Admin getAdmin(@PathVariable("admin_phone") String admin_phone) {
        return adminMapper.getAdminByPhone(admin_phone);
    }

    // 모든 관리자 정보 조회
    @GetMapping("/all")
    public List<AdminDTO> getAdmins() {
        List<Admin> admins = adminMapper.getAdmins();
        List<AdminDTO> adminDTOs = new ArrayList<>();

        for (Admin admin : admins) {
            AdminDTO adminDTO = new AdminDTO();
            adminDTO.setId(admin.getAdmin_id());
            adminDTO.setPw(admin.getAdmin_pw());
            adminDTOs.add(adminDTO);
        }

        return adminDTOs;
    }

    // 관리자 정보 수정
    @PutMapping("/info_update/{admin_phone}")
    public void putAdmin(@PathVariable("admin_phone") String admin_phone, @RequestBody Admin updatedAdmin) {
        updatedAdmin.setAdmin_phone(admin_phone);
        adminMapper.updateAdmin(updatedAdmin);
    }

    // 관리자 등록
    @PostMapping("/signup/{admin_phone}")
    public void postAdmin(@PathVariable("admin_phone") String admin_phone, @RequestBody Admin admin) {
        admin.setAdmin_phone(admin_phone);
        adminMapper.insertAdmin(admin);
    }

    // 관리자 삭제
    @DeleteMapping("/delAdmin/{admin_phone}")
    public void deleteAdmin(@PathVariable("admin_phone") String admin_phone) {
        adminMapper.deleteAdmin(admin_phone);
    }

    // 매장 ID로 해당 매장의 메뉴 리스트 조회
    @GetMapping("/menus/{store_id}")
    public List<Menu> getMenusByStoreId(@PathVariable("store_id") Long store_id) {
        return storeMapper.getMenusByStoreId(store_id);
    }

    // 메뉴 추가
    @PostMapping("/menus/add")
    public void addMenu(@RequestBody Menu menu) {
        storeMapper.insertMenu(menu);
    }

    // 메뉴 업데이트
    @PutMapping("/menus/update/{menu_id}")
    public void updateMenu(@PathVariable("menu_id") Long menu_id, @RequestBody Menu updatedMenu) {
        updatedMenu.setMenu_id(menu_id);
        storeMapper.updateMenu(updatedMenu);
    }

    // 메뉴 삭제
    @DeleteMapping("/menus/delete/{menu_id}")
    public void deleteMenu(@PathVariable("menu_id") Long menu_id) {
        storeMapper.deleteMenu(menu_id);
    }
}
