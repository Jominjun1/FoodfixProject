package com.project.foodfix.controller;

import com.project.foodfix.mapper.UserMapper;
import com.project.foodfix.model.User;
import com.project.foodfix.model.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserMapper userMapper;

    @Autowired
    public UserController(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    // 특정 사용자 정보 조회
    @GetMapping("/{user_id}")
    public User getUser(@PathVariable("user_id") String user_id) {
        return userMapper.getUserById(user_id);
    }

    // 모든 사용자 정보 조회
    @GetMapping("/all")
    public List<UserDTO> getUserList() {
        List<User> userList = userMapper.getUsers();
        List<UserDTO> userDTOList = new ArrayList<>();
        for (User user : userList) {
            UserDTO userDTO = new UserDTO();
            userDTO.setUser_id(user.getUser_id());
            userDTO.setUser_pw(user.getUser_pw());
            userDTOList.add(userDTO);
        }
        return userDTOList;
    }

    // 로그인
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody UserDTO loginRequest) {
        String user_id = loginRequest.getUser_id();
        String user_pw = loginRequest.getUser_pw();

        User user = userMapper.getUserById(user_id);

        if (user != null) {
            if (user.getUser_pw().equals(user_pw)) {
                return ResponseEntity.ok("로그인 성공");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("비밀번호가 일치하지 않습니다");
            }
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("사용자를 찾을 수 없습니다");
        }
    }

    // 사용자 정보 수정
    @PutMapping("/info/{user_id}")
    public void putUser(@PathVariable("user_id") String user_id, @RequestBody User updatedUser) {
        updatedUser.setUser_id(user_id);
        userMapper.updateUser(updatedUser);
    }

    // 사용자 등록
    @PostMapping("/signup/{user_id}")
    public void postUser(@PathVariable("user_id") String user_id, @RequestBody User user) {
        user.setUser_id(user_id);
        userMapper.insertUser(user);
    }

    // 사용자 삭제
    @DeleteMapping("/del/{user_id}")
    public void deleteUser(@PathVariable("user_id") String user_id) {
        userMapper.deleteUser(user_id);
    }
}
