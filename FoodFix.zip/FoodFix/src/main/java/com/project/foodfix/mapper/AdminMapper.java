package com.project.foodfix.mapper;

import com.project.foodfix.model.Admin;

import java.util.List;

public interface AdminMapper {

    Admin getAdminByPhone(String admin_phone);

    List<Admin> getAdmins();

    int insertAdmin(Admin admin);

    int updateAdmin(Admin admin);

    int deleteAdmin(String admin_phone);
}
