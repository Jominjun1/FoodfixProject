package com.project.foodfix.mapper;

import com.project.foodfix.model.Menu;
import com.project.foodfix.model.Store;

import java.util.List;

public interface StoreMapper {

    Store getStoreById(Long store_id);

    List<Store> getStoresByAdminId(String admin_id);

    List<Store> getAllStores();

    int insertStore(Store store);

    int updateStore(Store store);

    int deleteStore(Long store_id);

    List<Menu> getMenusByStoreId(Long store_id);

    Menu getMenuById(Long menu_id);

    int insertMenu(Menu menu);

    int updateMenu(Menu menu);

    int deleteMenu(Long menu_id);
}
