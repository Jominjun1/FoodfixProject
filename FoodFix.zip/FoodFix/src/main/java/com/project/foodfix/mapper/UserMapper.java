package com.project.foodfix.mapper;

import com.project.foodfix.model.User;

import java.util.List;

public interface UserMapper {

    User getUserById(String user_id);

    List<User> getUsers();

    int insertUser(User user);

    int updateUser(User user);

    int deleteUser(String user_id);
}
