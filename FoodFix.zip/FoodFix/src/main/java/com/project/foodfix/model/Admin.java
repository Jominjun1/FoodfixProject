package com.project.foodfix.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class Admin {

    private String admin_phone;
    private List<Store> stores;
    private String admin_id;
    private String admin_name;
    private String admin_pw;
    private String admin_address;

}
