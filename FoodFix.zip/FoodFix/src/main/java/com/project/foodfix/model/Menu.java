package com.project.foodfix.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Menu {

    private Long menu_id;
    private String menu_name;
    private double menu_price;
    private String explanation;
    private String menu_image;
    private Store store;
}
