package com.project.foodfix.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class Store {

    private Long store_id;
    private String store_name;
    private String store_address;
    private String store_category;
    private Admin admin;
    private List<Menu> menus;

}
