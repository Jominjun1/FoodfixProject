package com.project.foodfix.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class User {

    private String user_id;
    private String user_phone;
    private String user_name;
    private String user_pw;
    private String user_address;
    private String nickname;
    private String male;

}
