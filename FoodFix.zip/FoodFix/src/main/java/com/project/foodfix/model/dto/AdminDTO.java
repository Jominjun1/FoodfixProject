package com.project.foodfix.model.dto;

import lombok.*;

@Getter
@Setter
public class AdminDTO {
    private String id;
    private String pw;
}
