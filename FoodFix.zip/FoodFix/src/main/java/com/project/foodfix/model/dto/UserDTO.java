package com.project.foodfix.model.dto;

import lombok.*;

@Getter
@Setter
public class UserDTO {
    private String user_id;
    private String user_pw;

}
