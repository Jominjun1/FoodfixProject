package com.project.foodfix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodFixApplicationTests {

    @Test
    void contextLoads() {
    }

}
